with open("datos.txt", "r") as f:
    for linea in f:
        print("Línea leída: ", linea.strip())